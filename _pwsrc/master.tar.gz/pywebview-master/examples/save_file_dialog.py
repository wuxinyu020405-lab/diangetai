"""Create a save file dialog after a delay."""

import webview


def save_file_dialog(window):
    import time

    time.sleep(5)
    result = window.create_file_dialog(
        webview.FileDialog.SAVE, directory='/', save_filename='test.file'
    )
    print(result)


if __name__ == '__main__':
    window = webview.create_window('Save file dialog', 'https://pywebview.flowrl.com/hello')
    webview.start(save_file_dialog, window)
